// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyB2IpeAPZ_9ooScAVMALM6Sjyb1SuTzgr4",
    authDomain: "snake-mix.firebaseapp.com",
    databaseURL: "https://snake-mix-default-rtdb.firebaseio.com",
    projectId: "snake-mix",
    storageBucket: "snake-mix.appspot.com",
    messagingSenderId: "467767092848",
    appId: "1:467767092848:web:afe72331c06ce3f52e36b5"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);