document.getElementById("play").addEventListener("click", PlayButton);

function PlayButton()
{
    document.getElementById("menu").style.display = "none";
}